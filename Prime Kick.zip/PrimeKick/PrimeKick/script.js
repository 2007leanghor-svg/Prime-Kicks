/* ================================================
   PRIMEKICK – Main Application JavaScript
================================================ */

"use strict";

/* ---- DATA ---- */
const PRODUCTS_DATA = [
  { id: 1,  name: "Nike Air Force",     category: "sneakers", price: 129, oldPrice: 179, image: "https://static.nike.com/a/images/t_web_pdp_535_v2/f_auto,u_9ddf04c7-2a9a-4d76-add1-d15af8f0263d,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/57558712-5ebe-4abb-9984-879f9e896b4c/W+AIR+FORCE+1+%2707+FLYEASE.png", rating: 4.8, badge: "bestseller", description: "Lightweight and breathable, perfect for all-day wear. Featuring responsive cushioning and a sleek silhouette." },
  { id: 2,  name: "Timberland",          category: "boots",    price: 210, oldPrice: null, image: "https://assets.timberland.com/images/t_img/f_auto,h_650,e_sharpen:60,w_650/dpr_2.0/v1741199070/TB110061713-HERO/Mens-Timberland-Premium-6Inch-Waterproof-Boot-TBL-Wheat-Nubuck-HERO.png", rating: 4.7, badge: "new", description: "Classic boot crafted from full-grain leather. A timeless silhouette that transitions effortlessly from day to evening." },
  { id: 3,  name: "Aurelia Stiletto",    category: "heels",    price: 165, oldPrice: 210, image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=900&q=80", rating: 4.9, badge: "new", description: "Sculptural heels designed to elevate every outfit with confidence and comfort." },
  { id: 4,  name: "Mira Sandals",        category: "sandals",  price: 95, oldPrice: 120, image: "https://www.birkenstock.com/dw/image/v2/BLFX_PRD/on/demandware.static/-/Sites-master-catalog-emea/default/dwdcb12ec6/1030814/1030814.jpg?sw=656&sh=656&sm=fit&q=100", rating: 4.7, badge: "sale", description: "Comfortable sandals with a polished finish, ideal for sunny days and relaxed evenings." },
  { id: 5,  name: "Velocity Runner",     category: "sports",   price: 140, oldPrice: 180, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80", rating: 4.8, badge: "bestseller", description: "Responsive running shoes built for speed, comfort, and all-day training support." },
  { id: 12, name: "Derby Lace-Up",       category: "formal",   price: 189, oldPrice: null, image: "https://assets.designerbrands.com/match/Site_Name/514783_967_ss_01/?quality=70&io=transform:fit,width:1600", rating: 4.6, badge: null, description: "Polished Derby shoes with cap-toe detailing. Crafted from smooth leather for a refined, professional look." },
];

const CATEGORIES_INFO = {
  sneakers: { label: "Sneakers", img: "https://static.nike.com/a/images/t_web_pdp_535_v2/f_auto,u_9ddf04c7-2a9a-4d76-add1-d15af8f0263d,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/57558712-5ebe-4abb-9984-879f9e896b4c/W+AIR+FORCE+1+%2707+FLYEASE.png", desc: "Street-ready kicks for everyday style" },
  boots:    { label: "Boots",    img: "https://static.nike.com/a/images/t_web_pw_592_v2/f_auto/u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/6bfdf001-0892-41d2-87bd-a5c774811402/WMNS+AIR+JORDAN+1+BROOKLYN.png", desc: "Bold boots for any season" },
  heels:    { label: "Heels",    img: "https://i.pinimg.com/736x/9f/34/5a/9f345aff2a86f6d2d0508c1c1949f478.jpg", desc: "Elegant heels for special occasions" },
  sandals:  { label: "Sandals",  img: "https://www.birkenstock.com/dw/image/v2/BLFX_PRD/on/demandware.static/-/Sites-master-catalog-emea/default/dwdcb12ec6/1030814/1030814.jpg?sw=656&sh=656&sm=fit&q=100", desc: "Breezy sandals for warm days" },
  sports:   { label: "Sports",   img: "https://static.nike.com/a/images/t_web_pdp_535_v2/f_auto,u_9ddf04c7-2a9a-4d76-add1-d15af8f0263d,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/ytro9wpdhmrfkqa3vdlw/AIR+MAX+UPTEMPO+%2795.png", desc: "Performance footwear for athletes" },
  formal:   { label: "Formal",   img: "https://img2.ans-media.com/i/840x1260/AW25-OBU0BR-28X_F1.webp?v=1761639633", desc: "Classic shoes for professional occasions" },
};

const ADMIN_CREDENTIALS = { email: "admin@gmail.com", password: "admin123", role: "admin" };


/* ================================================
   PRODUCTS PERSISTENCE
================================================ */
function loadProducts() {
  const saved = localStorage.getItem("sh_products");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const normalized = parsed.map(product => {
          const defaultProduct = PRODUCTS_DATA.find(item => item.category === product.category && item.name === product.name);
          if (!defaultProduct) return product;
          return { ...product, ...defaultProduct, id: product.id || defaultProduct.id };
        });

        const missingProducts = PRODUCTS_DATA.filter(product => !parsed.some(existing => existing.category === product.category && existing.name === product.name));
        if (missingProducts.length > 0 || normalized.some((product, index) => JSON.stringify(product) !== JSON.stringify(parsed[index]))) {
          const updated = [...normalized];
          missingProducts.forEach(product => {
            updated.push({ ...product, id: Math.max(...updated.map(item => Number(item.id) || 0), 0) + 1 });
          });
          localStorage.setItem("sh_products", JSON.stringify(updated));
          return updated;
        }
        return normalized;
      }
    } catch (e) {}
  }
  localStorage.setItem("sh_products", JSON.stringify(PRODUCTS_DATA));
  return [...PRODUCTS_DATA];
}
function saveProducts() {
  localStorage.setItem("sh_products", JSON.stringify(state.products));
}

/* ================================================
   ORDERS PERSISTENCE — per user
================================================ */
function ordersKey(email) { return "sh_orders_" + (email || "guest"); }
function loadOrders(email) {
  try { return JSON.parse(localStorage.getItem(ordersKey(email)) || "[]"); }
  catch (e) { return []; }
}
function saveOrders() {
  if (!state.currentUser) return;
  localStorage.setItem(ordersKey(state.currentUser.email), JSON.stringify(state.orders));
}

/* ---- STATE ---- */
let state = {
  products:     loadProducts(),
  cart:         JSON.parse(localStorage.getItem("sh_cart")     || "[]"),
  wishlist:     JSON.parse(localStorage.getItem("sh_wishlist") || "[]"),
  orders:       [],
  users:        JSON.parse(localStorage.getItem("sh_users")    || "[]"),
  currentUser:  JSON.parse(localStorage.getItem("sh_user")     || "null"),
  currentRole:  "client",
  shopFilter:   { cats: [], priceMax: 2000, sort: "default", search: "" },
  selectedSize: null,
};

// Restore orders for already-logged-in user on refresh
if (state.currentUser) {
  state.orders = loadOrders(state.currentUser.email);
}

/* ---- SAVE ---- */
function save() {
  localStorage.setItem("sh_cart",     JSON.stringify(state.cart));
  localStorage.setItem("sh_wishlist", JSON.stringify(state.wishlist));
  localStorage.setItem("sh_users",    JSON.stringify(state.users));
  localStorage.setItem("sh_user",     JSON.stringify(state.currentUser));
  saveProducts();
  saveOrders();
}

/* ================================================
   NAVIGATION
================================================ */
const PROTECTED_PAGES = [];

function navigateTo(page) {
  if (PROTECTED_PAGES.includes(page) && !state.currentUser) {
    navigateTo("home");
    return;
  }

  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-link").forEach(l => l.classList.remove("active"));

  const pageEl = document.getElementById("page-" + page);
  if (pageEl) pageEl.classList.add("active");
  const navEl = document.querySelector(`.nav-link[data-page="${page}"]`);
  if (navEl) navEl.classList.add("active");

  window.scrollTo({ top: 0, behavior: "smooth" });
  closeNav();

  if (page === "home")       renderFeaturedProducts();
  if (page === "shop")       renderShop();
  if (page === "categories") renderCategoriesPage();
  if (page === "cart")       renderCart();
  if (page === "wishlist")   renderWishlist();
  if (page === "checkout")   renderCheckout();
  if (page === "account")    renderAccount();
  if (page === "login")      resetAuthForms();
}

/* ---- Reset auth forms to blank ---- */
function resetAuthForms() {
  const loginEmail = document.getElementById("loginEmail");
  const loginPassword = document.getElementById("loginPassword");
  const loginError = document.getElementById("loginError");
  const regFirst = document.getElementById("regFirst");
  const regLast = document.getElementById("regLast");
  const regEmail = document.getElementById("regEmail");
  const regPhone = document.getElementById("regPhone");
  const regPassword = document.getElementById("regPassword");
  const regConfirm = document.getElementById("regConfirm");
  const regError = document.getElementById("regError");

  if (loginEmail) loginEmail.value = "";
  if (loginPassword) loginPassword.value = "";
  if (loginError) loginError.textContent = "";
  if (regFirst) regFirst.value = "";
  if (regLast) regLast.value = "";
  if (regEmail) regEmail.value = "";
  if (regPhone) regPhone.value = "";
  if (regPassword) regPassword.value = "";
  if (regConfirm) regConfirm.value = "";
  if (regError) regError.textContent = "";

  document.querySelectorAll(".role-btn").forEach(b => b.classList.remove("active"));
  const clientRole = document.querySelector('.role-btn[data-role="client"]');
  if (clientRole) clientRole.classList.add("active");
  state.currentRole = "client";

  document.querySelectorAll(".auth-tab").forEach(t  => t.classList.toggle("active", t.dataset.tab === "login"));
  document.querySelectorAll(".auth-panel").forEach(p => p.classList.toggle("active", p.id === "panel-login"));
}

/* ---- Nav click delegation ---- */
document.addEventListener("click", function (e) {
  const pg = e.target.closest("[data-page]");
  if (pg) {
    e.preventDefault();
    navigateTo(pg.getAttribute("data-page"));
  }
  const cat = e.target.closest("[data-cat]");
  if (cat) {
    e.preventDefault();
    filterByCategory(cat.getAttribute("data-cat"));
  }
});

document.querySelector(".nav-logo").addEventListener("click", () => navigateTo("home"));

const hamburger = document.getElementById("hamburger");
const navLinks  = document.getElementById("navLinks");
hamburger.addEventListener("click", () => navLinks.classList.toggle("open"));
function closeNav() { navLinks.classList.remove("open"); }

window.addEventListener("scroll", () => {
  document.getElementById("navbar").classList.toggle("scrolled", window.scrollY > 50);
});

function filterByCategory(cat) {
  navigateTo("shop");
  state.shopFilter.cats = [cat];
  setTimeout(() => {
    document.querySelectorAll("#catFilterList input").forEach(cb => {
      cb.checked = cb.value === cat || cb.value === "all";
    });
    renderShop();
  }, 50);
}

/* ================================================
   PRODUCT CARD
================================================ */
function createProductCard(product) {
  const inWish       = state.wishlist.find(w => w.id === product.id);
  const stars        = "★".repeat(Math.floor(product.rating)) + (product.rating % 1 >= 0.5 ? "☆" : "");
  const badgeHTML    = product.badge    ? `<div class="product-badge ${product.badge === "sale" ? "sale" : ""}">${product.badge}</div>` : "";
  const oldPriceHTML = product.oldPrice ? `<span class="product-old-price">$${product.oldPrice}</span>` : "";

  const card = document.createElement("div");
  card.className  = "product-card";
  card.dataset.id = product.id;
  card.innerHTML  = `
    <div class="product-img-wrap">
      <img src="${product.image}" alt="${product.name}" loading="lazy"/>
      ${badgeHTML}
      <div class="product-actions">
        <button class="product-action-btn btn-wishlist ${inWish ? "wishlisted" : ""}" title="Wishlist">
          <i class="fa${inWish ? "s" : "r"} fa-heart"></i>
        </button>
        <button class="product-action-btn btn-quick-view" title="Quick View">
          <i class="fas fa-eye"></i>
        </button>
      </div>
    </div>
    <div class="product-info">
      <div class="product-cat">${product.category}</div>
      <div class="product-name">${product.name}</div>
      <div class="product-rating">
        <span class="product-stars">${stars}</span>
      </div>
      <div class="product-footer">
        <div>
          <span class="product-price">$${product.price}</span>
          ${oldPriceHTML}
        </div>
        <button class="btn-add-cart" data-id="${product.id}">
          <i class="fas fa-bag-shopping"></i> Add
        </button>
      </div>
    </div>
  `;

  card.querySelector(".btn-wishlist").addEventListener("click",   e => { e.stopPropagation(); toggleWishlist(product); });
  card.querySelector(".btn-quick-view").addEventListener("click", e => { e.stopPropagation(); openProductModal(product); });
  card.querySelector(".btn-add-cart").addEventListener("click",   e => { e.stopPropagation(); addToCart(product); });
  card.querySelector(".product-img-wrap img").addEventListener("click", () => openProductModal(product));
  return card;
}

/* ================================================
   FEATURED PRODUCTS
================================================ */
function renderFeaturedProducts() {
  const el = document.getElementById("featuredProducts");
  if (!el) return;
  el.innerHTML = "";
  let featured = state.products.filter(p => p.badge === "bestseller" || p.badge === "new").slice(0, 4);
  if (featured.length < 4) featured = state.products.slice(0, 4);
  featured.forEach(p => el.appendChild(createProductCard(p)));
}

/* ================================================
   SHOP PAGE
================================================ */
function renderShop() {
  let products = [...state.products];
  const f = state.shopFilter;

  if (f.cats.length > 0) products = products.filter(p => f.cats.includes(p.category));
  products = products.filter(p => p.price <= f.priceMax);
  if (f.search) {
    const q = f.search.toLowerCase();
    products = products.filter(p => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
  }
  if (f.sort === "price-asc")       products.sort((a, b) => a.price - b.price);
  else if (f.sort === "price-desc") products.sort((a, b) => b.price - a.price);
  else if (f.sort === "name")       products.sort((a, b) => a.name.localeCompare(b.name));

  const el = document.getElementById("shopProducts");
  el.innerHTML = "";
  if (products.length === 0) {
    el.innerHTML = '<p class="empty-msg">No products found. Try adjusting filters.</p>';
  } else {
    products.forEach(p => el.appendChild(createProductCard(p)));
  }
  const countEl = document.getElementById("productCount");
  if (countEl) countEl.textContent = `${products.length} product${products.length !== 1 ? "s" : ""}`;
}

/* ---- Shop Filters ---- */
document.getElementById("catFilterList").addEventListener("change", e => {
  const val = e.target.value;
  if (val === "all") {
    document.querySelectorAll("#catFilterList input").forEach(cb => cb.checked = cb.value === "all");
    state.shopFilter.cats = [];
  } else {
    document.querySelector('#catFilterList input[value="all"]').checked = false;
    state.shopFilter.cats = [...document.querySelectorAll("#catFilterList input:checked")].map(cb => cb.value);
  }
  renderShop();
});

document.getElementById("priceRange").addEventListener("input", e => {
  state.shopFilter.priceMax = +e.target.value;
  document.getElementById("priceVal").textContent = `$${e.target.value}`;
  renderShop();
});

document.getElementById("sortSelect").addEventListener("change", e => {
  state.shopFilter.sort = e.target.value;
  renderShop();
});

let searchTimeout;
document.getElementById("searchInput").addEventListener("input", e => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => { state.shopFilter.search = e.target.value; renderShop(); }, 300);
});

/* ================================================
   CATEGORIES PAGE
================================================ */
function renderCategoriesPage() {
  const el = document.getElementById("catDetailGrid");
  el.innerHTML = "";
  Object.entries(CATEGORIES_INFO).forEach(([key, info]) => {
    const count = state.products.filter(p => p.category === key).length;
    const card  = document.createElement("div");
    card.className = "cat-detail-card";
    card.innerHTML = `
      <img src="${info.img}" alt="${info.label}" loading="lazy"/>
      <div class="cat-detail-info">
        <h3>${info.label}</h3>
        <p>${info.desc}</p>
        <p class="cat-count">${count} products</p>
        <button class="btn btn-primary btn-sm" style="margin-top:14px">Shop ${info.label}</button>
      </div>
    `;
    card.addEventListener("click", () => filterByCategory(key));
    el.appendChild(card);
  });
}

/* ================================================
   CART
================================================ */
function addToCart(product, qty = 1) {
  const existing = state.cart.find(i => i.id === product.id);
  if (existing) existing.qty += qty;
  else state.cart.push({ ...product, qty });
  save(); updateBadges();
  showToast(`🛍️ "${product.name}" added to cart!`);
}

function removeFromCart(id) {
  state.cart = state.cart.filter(i => i.id !== id);
  save(); updateBadges(); renderCart();
}

function updateQty(id, delta) {
  const item = state.cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(id); return; }
  save(); renderCart();
}

function renderCart() {
  const el      = document.getElementById("cartItems");
  const summary = document.getElementById("cartSummary");
  if (state.cart.length === 0) {
    el.innerHTML = `<p class="empty-msg">Your cart is empty. <a href="#" data-page="shop">Start shopping!</a></p>`;
    summary.style.display = "none";
    return;
  }
  el.innerHTML = "";
  let subtotal = 0;
  state.cart.forEach(item => {
    subtotal += item.price * item.qty;
    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <img src="${item.image}" alt="${item.name}"/>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-cat">${item.category}</div>
        <div class="cart-item-price">$${item.price}</div>
      </div>
      <div class="cart-item-right">
        <div class="qty-control">
          <button class="qty-btn" data-action="dec" data-id="${item.id}">−</button>
          <span class="qty-val">${item.qty}</span>
          <button class="qty-btn" data-action="inc" data-id="${item.id}">+</button>
        </div>
        <strong>$${(item.price * item.qty).toFixed(2)}</strong>
        <button class="btn-remove-cart" data-id="${item.id}"><i class="fas fa-trash"></i> Remove</button>
      </div>
    `;
    div.querySelector(".btn-remove-cart").addEventListener("click", () => removeFromCart(item.id));
    div.querySelectorAll(".qty-btn").forEach(btn => {
      btn.addEventListener("click", () => updateQty(item.id, btn.dataset.action === "inc" ? 1 : -1));
    });
    el.appendChild(div);
  });
  document.getElementById("cartSubtotal").textContent = `$${subtotal.toFixed(2)}`;
  document.getElementById("cartTotal").textContent     = `$${(subtotal + 5).toFixed(2)}`;
  summary.style.display = "block";
}

/* ================================================
   WISHLIST
================================================ */
function toggleWishlist(product) {
  const idx = state.wishlist.findIndex(w => w.id === product.id);
  if (idx > -1) { state.wishlist.splice(idx, 1); showToast(`💔 Removed from wishlist`); }
  else           { state.wishlist.push(product);  showToast(`❤️ Added to wishlist!`); }
  save(); updateBadges();
  document.querySelectorAll(`.product-card[data-id="${product.id}"] .btn-wishlist`).forEach(btn => {
    const inWish = state.wishlist.find(w => w.id === product.id);
    btn.classList.toggle("wishlisted", !!inWish);
    btn.innerHTML = `<i class="fa${inWish ? "s" : "r"} fa-heart"></i>`;
  });
  if (document.getElementById("page-wishlist").classList.contains("active")) renderWishlist();
}

function renderWishlist() {
  const el = document.getElementById("wishlistItems");
  el.innerHTML = "";
  if (state.wishlist.length === 0) { el.innerHTML = '<p class="empty-msg">Your wishlist is empty.</p>'; return; }
  state.wishlist.forEach(p => el.appendChild(createProductCard(p)));
}

/* ================================================
   CHECKOUT
================================================ */
function renderCheckout() {
  const orderEl = document.getElementById("checkoutOrderItems");
  orderEl.innerHTML = "";
  let sub = 0;
  state.cart.forEach(item => {
    sub += item.price * item.qty;
    const d = document.createElement("div");
    d.className = "co-item";
    d.innerHTML = `
      <img src="${item.image}" alt="${item.name}"/>
      <div class="co-item-info">
        <div class="co-item-name">${item.name} × ${item.qty}</div>
        <div class="co-item-price">$${(item.price * item.qty).toFixed(2)}</div>
      </div>
    `;
    orderEl.appendChild(d);
  });
  document.getElementById("coSubtotal").textContent = `$${sub.toFixed(2)}`;
  document.getElementById("coTotal").textContent     = `$${(sub + 5).toFixed(2)}`;
}

document.getElementById("checkoutForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const orderId = "ORD-" + Math.random().toString(36).substr(2, 6).toUpperCase();
  const order   = {
    id:     orderId,
    items:  [...state.cart],
    total:  state.cart.reduce((sum, i) => sum + i.price * i.qty, 0) + 5,
    date:   new Date().toLocaleDateString(),
    status: "Processing",
  };
  state.orders.push(order);
  state.cart = [];
  save(); updateBadges();
  document.getElementById("orderNum").textContent = `Order ID: ${orderId}`;
  document.getElementById("orderSuccessModal").classList.add("open");
});

document.getElementById("orderSuccessClose").addEventListener("click", () => {
  document.getElementById("orderSuccessModal").classList.remove("open");
  navigateTo("home");
});

document.querySelectorAll(".payment-opt input").forEach(radio => {
  radio.addEventListener("change", () => {
    document.getElementById("cardFields").style.display = radio.value === "card" ? "block" : "none";
  });
});

/* ================================================
   AUTH
================================================ */
document.querySelectorAll(".auth-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    const target = tab.dataset.tab;
    document.querySelectorAll(".auth-tab").forEach(t  => t.classList.remove("active"));
    document.querySelectorAll(".auth-panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    const targetPanel = document.getElementById("panel-" + target);
    if (targetPanel) targetPanel.classList.add("active");
  });
});

document.querySelectorAll("[data-tab]").forEach(link => {
  if (link.tagName === "A") {
    link.addEventListener("click", e => {
      e.preventDefault();
      const t = link.dataset.tab;
      document.querySelectorAll(".auth-tab").forEach(tb  => tb.classList.toggle("active", tb.dataset.tab === t));
      document.querySelectorAll(".auth-panel").forEach(p  => p.classList.toggle("active", p.id === "panel-" + t));
    });
  }
});

document.querySelectorAll(".role-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".role-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    state.currentRole = btn.dataset.role;
    const loginEmail = document.getElementById("loginEmail");
    const loginPassword = document.getElementById("loginPassword");
    const loginError = document.getElementById("loginError");
    if (loginEmail) loginEmail.value = "";
    if (loginPassword) loginPassword.value = "";
    if (loginError) loginError.textContent = "";
  });
});

const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass  = document.getElementById("loginPassword").value;
    const errEl = document.getElementById("loginError");
    errEl.textContent = "";

    if (email === ADMIN_CREDENTIALS.email && pass === ADMIN_CREDENTIALS.password) {
      showToast("Login is currently unavailable on this site.");
      navigateTo("home");
      return;
    }

    const user = state.users.find(u => u.email === email && u.password === pass);
    if (user) {
      showToast("Login is currently unavailable on this site.");
      navigateTo("home");
      return;
    }

    errEl.textContent = "Invalid email or password.";
  });
}

const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const first   = document.getElementById("regFirst").value.trim();
    const last    = document.getElementById("regLast").value.trim();
    const email   = document.getElementById("regEmail").value.trim();
    const phone   = document.getElementById("regPhone").value.trim();
    const pass    = document.getElementById("regPassword").value;
    const confirm = document.getElementById("regConfirm").value;
    const errEl   = document.getElementById("regError");
    errEl.textContent = "";

    if (pass !== confirm) { errEl.textContent = "Passwords do not match."; return; }
    if (state.users.find(u => u.email === email)) { errEl.textContent = "Email already registered."; return; }

    showToast("Account creation is currently unavailable on this site.");
    navigateTo("home");
  });
}

/* ================================================
   updateAuthUI — sync icon AND data-page with login state
   - Logged in:  gold checkmark icon, data-page="account"
   - Logged out: plain user icon,     data-page="login"
================================================ */
function updateAuthUI() {
  const icon = document.getElementById("accountIcon");
  if (!icon) return;
  if (state.currentUser) {
    icon.setAttribute("data-page", "account");
    icon.innerHTML = `<i class="fas fa-user-check" style="color:var(--gold-dark)"></i>`;
  } else {
    icon.setAttribute("data-page", "home");
    icon.innerHTML = `<i class="fas fa-user"></i>`;
  }
}

/* ================================================
   MY ACCOUNT
================================================ */
function renderAccount(forceRefreshProfile = true) {
  if (!state.currentUser) {
    navigateTo("home");
    return;
  }

  const u = state.currentUser;

  document.getElementById("accountName").textContent  = `${u.firstName || "User"} ${u.lastName || ""}`.trim();
  document.getElementById("accountEmail").textContent = u.email;
  document.getElementById("avatarCircle").textContent = (u.firstName || "U")[0].toUpperCase();

  if (forceRefreshProfile) {
    document.getElementById("profFirst").value = u.firstName || "";
    document.getElementById("profLast").value  = u.lastName  || "";
    document.getElementById("profEmail").value = u.email     || "";
    document.getElementById("profPhone").value = u.phone     || "";
  }

  document.getElementById("adminMenuLink").style.display = u.role === "admin" ? "flex" : "none";

  const ordersEl = document.getElementById("orderHistory");
  ordersEl.innerHTML = state.orders.length === 0
    ? '<p class="empty-msg">No orders yet.</p>'
    : state.orders.slice().reverse().map(o => `
        <div style="border:1px solid var(--border);border-radius:10px;padding:16px;margin-bottom:14px">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px">
            <strong>${o.id}</strong>
            <span style="color:var(--gold-dark);font-size:0.85rem">${o.status}</span>
          </div>
          <div style="color:var(--text-muted);font-size:0.85rem">${o.date} · ${o.items.length} item(s) · $${o.total.toFixed(2)}</div>
        </div>
      `).join("");

  const accWish = document.getElementById("accWishlist");
  accWish.innerHTML = "";
  if (state.wishlist.length === 0) accWish.innerHTML = '<p class="empty-msg">No saved items.</p>';
  else state.wishlist.forEach(p => accWish.appendChild(createProductCard(p)));

  if (u.role === "admin") {
    document.getElementById("adminTotalProducts").textContent = state.products.length;
    document.getElementById("adminTotalUsers").textContent    = state.users.length;
    const allOrders = state.users.reduce((acc, usr) => acc.concat(loadOrders(usr.email)), []);
    document.getElementById("adminTotalOrders").textContent   = allOrders.length;
    document.getElementById("adminRevenue").textContent       = "$" + allOrders.reduce((s, o) => s + o.total, 0).toFixed(0);
    renderAdminProducts();
  }
}

function renderAdminProducts() {
  const el = document.getElementById("adminProductList");
  el.innerHTML = "";

  const resetBar = document.createElement("div");
  resetBar.style.cssText = "display:flex;justify-content:flex-end;margin-bottom:16px;";
  resetBar.innerHTML = `
    <button id="resetProductsBtn" class="btn btn-outline btn-sm" style="font-size:0.82rem;color:var(--text-muted);border-color:var(--border);">
      <i class="fas fa-rotate-left"></i> Reset to Default Products
    </button>
  `;
  el.appendChild(resetBar);
  document.getElementById("resetProductsBtn").addEventListener("click", () => {
    if (!confirm("This will restore all default products. Continue?")) return;
    state.products = [...PRODUCTS_DATA];
    saveProducts();
    showToast("♻️ Products reset to defaults!");
    renderAdminProducts();
    document.getElementById("adminTotalProducts").textContent = state.products.length;
  });

  if (state.products.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-msg";
    empty.textContent = "No products. Add one or reset to defaults.";
    el.appendChild(empty);
    return;
  }

  state.products.forEach(p => {
    const row = document.createElement("div");
    row.className = "admin-product-row";
    row.innerHTML = `
      <img src="${p.image}" alt="${p.name}"/>
      <div class="aprod-info">
        <div class="aprod-name">${p.name}</div>
        <div class="aprod-meta">${p.category} · $${p.price}</div>
      </div>
      <button class="btn-delete-prod" data-id="${p.id}"><i class="fas fa-trash"></i> Delete</button>
    `;
    row.querySelector(".btn-delete-prod").addEventListener("click", () => {
      if (!confirm(`Delete "${p.name}"?`)) return;
      state.products = state.products.filter(pr => pr.id !== p.id);
      saveProducts();
      showToast("🗑️ Product deleted");
      renderAdminProducts();
      document.getElementById("adminTotalProducts").textContent = state.products.length;
    });
    el.appendChild(row);
  });
}

const saveProfileBtn = document.getElementById("saveProfile");
if (saveProfileBtn) {
  saveProfileBtn.addEventListener("click", () => {
    if (!state.currentUser) return;
    state.currentUser.firstName = document.getElementById("profFirst").value;
    state.currentUser.lastName  = document.getElementById("profLast").value;
    state.currentUser.phone     = document.getElementById("profPhone").value;
    const idx = state.users.findIndex(u => u.email === state.currentUser.email);
    if (idx > -1) state.users[idx] = { ...state.users[idx], ...state.currentUser };
    save();
    showToast("✅ Profile updated!");
  });
}

const logoutBtn = document.getElementById("logoutBtn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    state.currentUser = null;
    state.orders      = [];
    save(); updateAuthUI();
    showToast("👋 Logged out successfully");
    navigateTo("home");
  });
}

/* ================================================
   Account tab switching — safe, no login redirect.
   Only switches visible tab content; does NOT call
   navigateTo so it never triggers the login guard.
================================================ */
document.querySelectorAll(".account-menu li[data-acctab]").forEach(item => {
  item.addEventListener("click", () => {
    if (!state.currentUser) return;

    document.querySelectorAll(".account-menu li").forEach(l => l.classList.remove("active"));
    document.querySelectorAll(".acc-tab").forEach(t => t.classList.remove("active"));
    item.classList.add("active");
    const tab = document.getElementById("acctab-" + item.dataset.acctab);
    if (tab) tab.classList.add("active");

    // Refresh only the content of the newly active tab
    const tabKey = item.dataset.acctab;
    if (tabKey === "orders") {
      const ordersEl = document.getElementById("orderHistory");
      ordersEl.innerHTML = state.orders.length === 0
        ? '<p class="empty-msg">No orders yet.</p>'
        : state.orders.slice().reverse().map(o => `
            <div style="border:1px solid var(--border);border-radius:10px;padding:16px;margin-bottom:14px">
              <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                <strong>${o.id}</strong>
                <span style="color:var(--gold-dark);font-size:0.85rem">${o.status}</span>
              </div>
              <div style="color:var(--text-muted);font-size:0.85rem">${o.date} · ${o.items.length} item(s) · $${o.total.toFixed(2)}</div>
            </div>
          `).join("");
    } else if (tabKey === "wishlist-tab") {
      const accWish = document.getElementById("accWishlist");
      accWish.innerHTML = "";
      if (state.wishlist.length === 0) accWish.innerHTML = '<p class="empty-msg">No saved items.</p>';
      else state.wishlist.forEach(p => accWish.appendChild(createProductCard(p)));
    } else if (tabKey === "admin-panel" && state.currentUser.role === "admin") {
      document.getElementById("adminTotalProducts").textContent = state.products.length;
      document.getElementById("adminTotalUsers").textContent    = state.users.length;
      const allOrders = state.users.reduce((acc, usr) => acc.concat(loadOrders(usr.email)), []);
      document.getElementById("adminTotalOrders").textContent   = allOrders.length;
      document.getElementById("adminRevenue").textContent       = "$" + allOrders.reduce((s, o) => s + o.total, 0).toFixed(0);
      renderAdminProducts();
    }
    // profile tab needs no re-render — fields stay as typed
  });
});

// Add product (admin)
document.getElementById("addProductBtn").addEventListener("click", () => {
  document.getElementById("addProductModal").classList.add("open");
});
document.getElementById("addProductModalClose").addEventListener("click", () => {
  document.getElementById("addProductModal").classList.remove("open");
});
document.getElementById("addProductForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const newProd = {
    id:          Date.now(),
    name:        document.getElementById("apName").value,
    price:       +document.getElementById("apPrice").value,
    category:    document.getElementById("apCategory").value,
    image:       document.getElementById("apImage").value || "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80",
    description: document.getElementById("apDesc").value,
    rating: 4.5, badge: "new", oldPrice: null,
  };
  state.products.push(newProd);
  saveProducts();
  showToast("✅ Product added! Now visible in the shop.");
  document.getElementById("addProductModal").classList.remove("open");
  this.reset();
  renderAdminProducts();
  document.getElementById("adminTotalProducts").textContent = state.products.length;
  renderFeaturedProducts();
});

/* ================================================
   PRODUCT MODAL
================================================ */
function openProductModal(product) {
  const sizes  = ["38", "39", "40", "41", "42", "43", "44"];
  const inWish = state.wishlist.find(w => w.id === product.id);
  const modal  = document.getElementById("productModal");
  const body   = document.getElementById("modalBody");
  state.selectedSize = null;

  body.innerHTML = `
    <div class="modal-img"><img src="${product.image}" alt="${product.name}"/></div>
    <div class="modal-info">
      <div class="modal-cat">${product.category}</div>
      <h2>${product.name}</h2>
      <div style="margin-bottom:8px">
        <span style="color:var(--gold);font-size:1rem">${"★".repeat(Math.floor(product.rating))}</span>
      </div>
      <div class="modal-price">$${product.price} ${product.oldPrice ? `<span class="product-old-price">$${product.oldPrice}</span>` : ""}</div>
      <p class="modal-desc">${product.description}</p>
      <div class="size-label">Select Size:</div>
      <div class="size-options" id="sizeOptions">
        ${sizes.map(s => `<button class="size-btn" data-size="${s}">EU ${s}</button>`).join("")}
      </div>
      <div class="modal-actions">
        <button class="btn btn-primary" id="modalAddCart"><i class="fas fa-bag-shopping"></i> Add to Cart</button>
        <button class="btn btn-outline ${inWish ? "btn-gold" : ""}" id="modalWishlist">
          <i class="fa${inWish ? "s" : "r"} fa-heart"></i> ${inWish ? "Wishlisted" : "Wishlist"}
        </button>
      </div>
    </div>
  `;

  body.querySelectorAll(".size-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      body.querySelectorAll(".size-btn").forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      state.selectedSize = btn.dataset.size;
    });
  });
  body.querySelector("#modalAddCart").addEventListener("click",   () => { addToCart(product); modal.classList.remove("open"); });
  body.querySelector("#modalWishlist").addEventListener("click",  () => { toggleWishlist(product); modal.classList.remove("open"); });

  modal.classList.add("open");
}

document.getElementById("modalClose").addEventListener("click", () => {
  document.getElementById("productModal").classList.remove("open");
});
document.getElementById("productModal").addEventListener("click", e => {
  if (e.target === e.currentTarget) e.currentTarget.classList.remove("open");
});

/* ================================================
   CONTACT FORM
================================================ */
document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();
  showToast("✅ Message sent! We'll get back to you soon.");
  this.reset();
});

/* ================================================
   BADGES & UTILITY
================================================ */
function updateBadges() {
  document.getElementById("cartBadge").textContent     = state.cart.reduce((s, i) => s + i.qty, 0);
  document.getElementById("wishlistBadge").textContent = state.wishlist.length;
}

function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

/* ================================================
   INIT
================================================ */
function init() {
  const slider = document.getElementById("priceRange");
  slider.max   = 2000;
  slider.value = 2000;
  document.getElementById("priceVal").textContent = "$2000";

  updateBadges();
  updateAuthUI();   // correctly sets icon based on actual login state
  renderFeaturedProducts();
  document.getElementById("page-home").classList.add("active");
  document.querySelector('.nav-link[data-page="home"]').classList.add("active");
}

init();